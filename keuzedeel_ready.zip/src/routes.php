<?php
use Slim\App;
use Slim\Views\Twig;
use App\Database;
use App\Controllers\ProjectController;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

return function(App $app) {
    $container = $app->getContainer();
    $dbPath = $container->get('db_path');
    $db = new Database($dbPath);
    $pdo = $db->getPdo();
    $twig = Slim\Views\Twig::create(__DIR__ . '/../templates', ['cache' => false]);

    // instantiate controller
    $controller = new ProjectController($pdo, $twig, __DIR__ . '/../public/uploads');

    // public routes
    $app->get('/', [$controller, 'list']);
    $app->get('/projects', [$controller, 'list']);
    $app->get('/project/{id}', [$controller, 'single']);

    // simple admin auth (session)
    $app->get('/admin/login', function(Request $req, Response $res) use ($twig) {
        return $twig->render($res, 'admin_login.twig');
    });
    $app->post('/admin/login', function(Request $req, Response $res) {
        $data = $req->getParsedBody();
        // WARNING: simple hardcoded credentials for demo. Change in production.
        if (isset($data['password']) && $data['password'] === 'adminpass') {
            $_SESSION['is_admin'] = true;
            return $res->withHeader('Location', '/admin')->withStatus(302);
        }
        return $res->withHeader('Location', '/admin/login')->withStatus(302);
    });

    // admin middleware
    $adminMiddleware = function($request, $handler) {
        if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
            $response = new \Slim\Psr7\Response();
            return $response->withHeader('Location', '/admin/login')->withStatus(302);
        }
        return $handler->handle($request);
    };

    $app->group('/admin', function(App $group) use ($controller) {
        $group->get('', [$controller, 'adminList']);
        $group->get('/add', [$controller, 'showAdd']);
        $group->post('/add', [$controller, 'handleAdd']);
    })->add($adminMiddleware);

    $app->get('/admin/logout', function(Request $req, Response $res) {
        unset($_SESSION['is_admin']);
        return $res->withHeader('Location', '/')->withStatus(302);
    });
};
